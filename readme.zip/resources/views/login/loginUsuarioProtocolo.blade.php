<!DOCTYPE html>
<!-- saved from url=(0029)http://www.esporte.df.gov.br/ -->
<html lang="pt-BR"><!--<![endif]--><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Secretaria de Estado de Esporte e Lazer</title>

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="/sel_files/bootstrap.css" rel="stylesheet" type="text/css">
    <link href="/sel_files/icomoon.css" rel="stylesheet" type="text/css">
    <link href="/sel_files/style.css" rel="stylesheet" type="text/css">
    <link href="/sel_files/style(1).css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <script async="" src="/sel_files/analytics.js.download"></script><script src="/sel_files/jquery.js.download" type="text/javascript"></script>
    <script src="/sel_files/bootstrap.js.download" type="text/javascript"></script>
    <script type="text/javascript" src="/sel_files/cdn.min.js.download"></script>
    <link rel="dns-prefetch" href="http://s.w.org/">
    <script type="text/javascript">
        window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/12.0.0-1\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/www.esporte.df.gov.br\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.4.1"}};
        /*! This file is auto-generated */
        !function(e,a,t){var r,n,o,i,p=a.createElement("canvas"),s=p.getContext&&p.getContext("2d");function c(e,t){var a=String.fromCharCode;s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,e),0,0);var r=p.toDataURL();return s.clearRect(0,0,p.width,p.height),s.fillText(a.apply(this,t),0,0),r===p.toDataURL()}function l(e){if(!s||!s.fillText)return!1;switch(s.textBaseline="top",s.font="600 32px Arial",e){case"flag":return!c([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])&&(!c([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!c([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]));case"emoji":return!c([55357,56424,55356,57342,8205,55358,56605,8205,55357,56424,55356,57340],[55357,56424,55356,57342,8203,55358,56605,8203,55357,56424,55356,57340])}return!1}function d(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(i=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},o=0;o<i.length;o++)t.supports[i[o]]=l(i[o]),t.supports.everything=t.supports.everything&&t.supports[i[o]],"flag"!==i[o]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[i[o]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(r=t.source||{}).concatemoji?d(r.concatemoji):r.wpemoji&&r.twemoji&&(d(r.twemoji),d(r.wpemoji)))}(window,document,window._wpemojiSettings);
    </script><script src="/sel_files/wp-emoji-release.min.js.download" type="text/javascript" defer=""></script>
    <style type="text/css">
        img.wp-smiley,
        img.emoji {
            display: inline !important;
            border: none !important;
            box-shadow: none !important;
            height: 1em !important;
            width: 1em !important;
            margin: 0 .07em !important;
            vertical-align: -0.1em !important;
            background: none !important;
            padding: 0 !important;
        }
    </style>
    <link rel="stylesheet" id="wp-block-library-css" href="/sel_files/style.min.css" type="text/css" media="all">
    <link rel="https://api.w.org/" href="http://www.esporte.df.gov.br/wp-json/">
    <link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://www.esporte.df.gov.br/xmlrpc.php?rsd">
    <link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://www.esporte.df.gov.br/wp-includes/wlwmanifest.xml">
    <meta name="generator" content="WordPress 5.4.1">
    <link rel="canonical" href="http://www.esporte.df.gov.br/">
    <link rel="shortlink" href="http://www.esporte.df.gov.br/">
    <link rel="alternate" type="application/json+oembed" href="http://www.esporte.df.gov.br/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwww.esporte.df.gov.br%2F">
    <link rel="alternate" type="text/xml+oembed" href="http://www.esporte.df.gov.br/wp-json/oembed/1.0/embed?url=http%3A%2F%2Fwww.esporte.df.gov.br%2F&amp;format=xml">
    <style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><link rel="icon" href="http://www.esporte.df.gov.br/wp-conteudo/uploads/2020/05/cropped-1056a8b4-7fbd-4039-89dd-471b01e6d5e5-32x32.jpg" sizes="32x32">
    <link rel="icon" href="http://www.esporte.df.gov.br/wp-conteudo/uploads/2020/05/cropped-1056a8b4-7fbd-4039-89dd-471b01e6d5e5-192x192.jpg" sizes="192x192">
    <link rel="apple-touch-icon" href="http://www.esporte.df.gov.br/wp-conteudo/uploads/2020/05/cropped-1056a8b4-7fbd-4039-89dd-471b01e6d5e5-180x180.jpg">
    <meta name="msapplication-TileImage" content="http://www.esporte.df.gov.br/wp-conteudo/uploads/2020/05/cropped-1056a8b4-7fbd-4039-89dd-471b01e6d5e5-270x270.jpg">


    <link id="avast_os_ext_custom_font" href="chrome-extension://eofcbnmajmjmplflapaojjnihcjkigck/common/ui/fonts/fonts.css" rel="stylesheet" type="text/css">




</head><evlist></evlist>

<body cz-shortcut-listen="true">



<!-- MENU PARA DISPOSITIVO MÓVEL-->
<div class="menu-para-movel">
    <nav class="navbar navbar-default">
        <div class="container-fluid">
            <img src="/sel_files/cabecalhoSEL.jpg" alt="some text" width=100%">
            <img src="/sel_files/logo_gdf.jpg" alt="some text" width=30% align="center" >
            <h3>Protocolo SELDF</h3>
        </div>
    </nav>
</div>

<!-- PARTE DO LAYOUT QUE LISTA O NOME DA ADMINSTRAÇÃO ALÉM DA DATA E ÍCONES AO LADO DIREITO DE MÍDIAS SOCIAIS -->


<div class="topo-titulo-site">
    <div class="container">
        <div class="row">
            <div class="col-md-8 ancoras" style="margin-bottom: 5px">
                <a href="http://www.esporte.df.gov.br/home/">
                    <h1>Secretaria de Estado de Esporte e Lazer</h1>
                    <p class="sigla">SELDF</p>
                </a>
            </div>



        </div>
    </div>

    <!-- PARTE DO TOPO QUE APRESENTA O SISTEMA DE BUSCA -->
    <div class="busca">
        <div class="container">
            <div class="row">
                <div class="col-md-3 col-sm-3">
                    <a href="http://www.brasilia.df.gov.br/" target="_blank"><img src="/sel_files/ico-logo-gdf.svg" alt="Governo do Distrito Federal" style="height:100px"></a>
                </div>
                <div class="col-md-9" style="padding-top: 20px">
                    <h1>Protocolo SELDF</h1>
                </div>


            </div>
        </div>
    </div>




    <!-- PARTE DO TOPO QUE APRESENTA O MENU -->
    <div class="menu-principal">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-left">
                    <header id="masthead" class="site-header" role="banner">
                        <div class="header-main">
                            <nav id="primary-navigation" class="site-navigation primary-navigation" role="navigation">
{{--                                <button class="menu-toggle">Primary Menu</button>--}}
                                <div class="menu-menusec-container">
                                    <ul id="primary-menu" class="nav-menu">
                                        <li class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item current_page_item menu-item-home menu-item-2733">
                                        </li>
                                    </ul>
                                </div>
                            </nav>
                        </div>
                    </header><!-- #masthead -->
                </div>
            </div>
        </div>
    </div>
    @if(Session::get('msgcreate'))
        <div class="alert alert-{{Session::get('typealert')}}">
            <button type="button" class="close" data-dismiss="alert">
                <i class="ace-icon fa fa-times"></i>
            </button>
            <strong>{{Session::get('msgcreate')}}</strong>
            <br>
        </div>
    @endif

    <div class="col-md-12" style="text-align: center; padding-top: 10px">
        <h3>Entrar</h3>
        <p>Digite o e-mail cadastrado e senha</p>
    </div>

    <form style="width: 60%; margin-top: 30px" class="offset-2" method="post" action="/sel/protocolo">
        {{-- CSRF--}}
        {{csrf_field()}}
        <div class="form-group">
            <label for="loginUser">LOGIN</label>
            <input type="email" class="form-control" id="loginUser" name="loginUser" aria-describedby="emailHelp" placeholder="Digite seu e-mail." required>
            {{--            <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>--}}
        </div>
        <div class="form-group">
            <label for="passUser">SENHA</label>
            <input type="password" class="form-control" id="passUser" name="passUser" required>
            <div style="text-align: right">
                <a href="/sel/protocolo/newpassword">Esqueci a senha</a>
            </div>
        </div>
        <div style="text-align: center">
            <a href="/sel/protocolo"><button type="submit" class="btn btn-primary btn-sm" style="width: 60%">Entrar</button></a>
        </div>

    </form>

</div>
</body>



<!-- FIM do módulo RODAPÉ -->



<script src="/vendor/mask/jquery.mask.js"></script>

<script>
    $(document).ready(function(){
        $('.date').mask('00/00/0000');
        $('.time').mask('00:00');
        $('.date_time').mask('00/00/0000 00:00:00');
        $('.cep').mask('00000-000');
        $('.phone').mask('(00) 0000-0000');
        $('.cel').mask('(00) 00000-0000');
        $('.phone_us').mask('(000) 000-0000');
        $('.mixed').mask('AAA 000-S0S');
        $('.cpf').mask('000.000.000-00', {reverse: true});
        $('.cnpj').mask('00.000.000/0000-00', {reverse: true});
        $('.numeroComPonto').mask('000.000.000.000.000', {reverse: true});
        $('.money').mask('000.000.000.000.000,00', {reverse: true});
        $('.licencaSO').mask('AAAAA-AAAAA-AAAAA-AAAAA-AAAAA', {reverse: false});
        $('.anydesk').mask('000 000 000', {reverse: false});
        $('.tempo').mask('00:00:00:000', {reverse: false});
    });

</script>

<script>

    function testarEmail(){
        // console.log($('#emailProfissional').val())
        email = $('#emailProfissional').val()
        confemail = $('#confirmaEmailProfissional').val()



        if(email !== confemail){
            // console.log('jjjjj')
            $('#alertaEmail').attr('hidden',false)
        }else{
            $('#alertaEmail').attr('hidden',true)
        }

        // console.log('passou')
    }

    function mostrarCREF(tipoProfissional){

        if(parseFloat(tipoProfissional)==1){
            $('#divCREF').attr('hidden',true)
        }
        if(parseFloat(tipoProfissional)==2){
            $('#divCREF').attr('hidden',false)
        }
    }


    function checkRequired() {

        if($('#nomeProfissional').val() == ''){
            alert('O nome do Profissional é requerido.');
            $('#aceiteRegulamento').attr('checked', false)
            $('#nomeProfissional').focus()
            return false
        }

        if($('#emailProfissional').val() == ''){
            alert('O e-mail do Profissional é requerido. ');
            $('#aceiteRegulamento').attr('checked', false)
            $('#emailProfissional').focus()
            return false
        }
        if($('#confirmaEmailProfissional').val() == ''){
            alert('Confirme o email. ');
            $('#aceiteRegulamento').attr('checked', false)
            $('#confirmaEmailProfissional').focus()
            return false
        }
        if((!$('#estagiario').prop('checked')) && (!$('#professor').prop('checked')) ){
            alert('Escolha o tipo de Profissional.');
            $('#aceiteRegulamento').attr('checked', false)
            $('#estagiario').focus()
            return false
        }
        if($('#nascProfissional').val() == ''){
            alert('Data Nascimento requerida. ');
            $('#aceiteRegulamento').attr('checked', false)
            $('#nascProfissional').focus()
            return false
        }
        if($('#rgProfissional').val() == ''){
            alert('RG é requerido. ');
            $('#aceiteRegulamento').attr('checked', false)
            $('#rgProfissional').focus()
            return false
        }
        if($('#cpfProfissional').val() == ''){
            alert('CPF é requerido. ');
            $('#aceiteRegulamento').attr('checked', false)
            $('#cpfProfissional').focus()
            return false
        }
        if($('#celProfissional').val() == ''){
            alert('Celular é requerido. ');
            $('#aceiteRegulamento').attr('checked', false)
            $('#celProfissional').focus()
            return false
        }
        if($('#celProfissional').val().length != 15){
            alert('Número de Celular inválido.');
            $('#aceiteRegulamento').attr('checked', false)
            $('#celProfissional').focus()
            return false
        }
        if($('#localProfissional').val() == 'Selecione a cidade de atuação'){
            alert('Selecione o local de atuação. ');
            $('#aceiteRegulamento').attr('checked', false)
            $('#localProfissional').focus()
            return false
        }
        if($('#especialidadeProfissional').val() == 'Selecione a Especialidade'){
            alert('Selecione uma Especialidade. ');
            $('#aceiteRegulamento').attr('checked', false)
            $('#especialidadeProfissional').focus()
            return false
        }
        if($('#dispProfissional').val() == 'Selecione'){
            alert('Selecione o período de preferência. ');
            $('#aceiteRegulamento').attr('checked', false)
            $('#dispProfissional').focus()
            return false
        }
        if((!$('#Segunda').prop('checked')) && (!$('#Terca').prop('checked')) && (!$('#Quarta').prop('checked')) && (!$('#Quinta').prop('checked')) && (!$('#Sexta').prop('checked')) && (!$('#Sabado').prop('checked')) && (!$('#Domingo').prop('checked')) ){
            alert('Escolha pelo menos um dia da Semana.');
            $('#aceiteRegulamento').attr('checked', false)
            $('#Segunda').focus()
            return false
        }
        if($('#horaInicioProfissional').val() == '') {
            alert('Defina a hora de início.');
            $('#aceiteRegulamento').attr('checked', false)
            $('#horaInicioProfissional').focus()
            return false
        }
        if($('#horaFimProfissional').val() == '') {
            alert('Defina a hora final.');
            $('#aceiteRegulamento').attr('checked', false)
            $('#horaFimProfissional').focus()
            return false
        }
        if($('#horaFimProfissional').val() <= $('#horaInicioProfissional').val()) {
            alert('A hora final deve ser maior que a de início.');
            $('#aceiteRegulamento').attr('checked', false)
            $('#horaFimProfissional').focus()
            return false
        }
        if($('#estagiario').prop('checked')) {
            $('#crefProfissional').attr('required', false)
        }else{
            $('#crefProfissional').attr('required', true)
        }

        testaAceite()

    }

    function testaAceite() {
        if($('#aceiteRegulamento').prop('checked')){
            $('#btnEnviar').attr('disabled', false)
        }else{
            $('#btnEnviar').attr('disabled', true)
        }
    }
    function validaCPF()
    {
        cpf = $('#cpfProfissional').val()
        // cpf = $('#cpfPessoa').val();
        cpf = cpf.replace(/[^\d]+/g,'');

        if(cpf == ''){

            $('#alertCPF').show();
        }
        // Elimina CPFs invalidos conhecidos
        if (cpf.length != 11 ||
            cpf == "00000000000" ||
            cpf == "11111111111" ||
            cpf == "22222222222" ||
            cpf == "33333333333" ||
            cpf == "44444444444" ||
            cpf == "55555555555" ||
            cpf == "66666666666" ||
            cpf == "77777777777" ||
            cpf == "88888888888" ||
            cpf == "99999999999"){

            $('#alertCPF').show();
            return false;
        }

        // Valida 1o digito
        add = 0;
        for (i=0; i < 9; i ++)
            add += parseInt(cpf.charAt(i)) * (10 - i);
        rev = 11 - (add % 11);
        if (rev == 10 || rev == 11)
            rev = 0;
        if (rev != parseInt(cpf.charAt(9))){
            $('#alertaCPF').attr('hidden', false);
            return false;
        }

        // Valida 2o digito
        add = 0;
        for (i = 0; i < 10; i ++)
            add += parseInt(cpf.charAt(i)) * (11 - i);
        rev = 11 - (add % 11);
        if (rev == 10 || rev == 11)
            rev = 0;
        if (rev != parseInt(cpf.charAt(10))){
            $('#alertaCPF').attr('hidden', false);
            return false;
        }
        // console.log('cerfto');
        $('#alertaCPF').attr('hidden', true);
        return true;
    }

    function timeFromTimestamp(date)
    {
        data = date.split(' ').reverse();
        return data[0];

    }

    function dateToBR(date)
    {
        data = date.split(' ').reverse();
        return data[1].split('-').reverse().join('/');
    }


</script>

{{--<script src="/vendor/jquery/jquery.js"></script>--}}
<script type="text/javascript">
    $(".alert").fadeTo(2000, 5000).slideUp(500, function(){
        $(".alert").slideUp(500);
    });
</script>

<footer>
    <hr>
    <div class="offset-2">
        <a href="/sel/protocolo/userCad">Não tem senha? Cadastre-se</a>
    </div>
    <br>

</footer>